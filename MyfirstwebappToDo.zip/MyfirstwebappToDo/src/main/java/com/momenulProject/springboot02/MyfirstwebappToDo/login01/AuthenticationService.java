package com.momenulProject.springboot02.MyfirstwebappToDo.login01;

import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {
	
	public boolean authenticate(String username, String password) {
		
		boolean isValidUser = username.equalsIgnoreCase("Momenul");
		boolean isValidpassword= password.equalsIgnoreCase("password");
		return isValidUser && isValidpassword;
	}

}
