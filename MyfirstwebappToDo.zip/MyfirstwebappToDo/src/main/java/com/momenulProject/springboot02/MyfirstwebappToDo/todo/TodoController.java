package com.momenulProject.springboot02.MyfirstwebappToDo.todo;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import jakarta.validation.Valid;

@Controller
//@SessionAttributes({"name","todos"})
@SessionAttributes("name")
public class TodoController {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private TodoService todoservice= new TodoService();
	
	@RequestMapping("/toDoList")
	private String toDoList(ModelMap model) {
		List<Todo> todos=todoservice.findByUserName("Momenul");
		model.addAttribute("todos", todos);
		return "listtodos";
	}
	
	@RequestMapping(value="/add-todo",method= RequestMethod.GET)
	private String addTodo(ModelMap model) {
		String name= (String) model.get("name");
		Todo todo =new Todo(0,name,"",LocalDate.now().plusYears(1),false);
		model.addAttribute("todo", todo);
		return "addToDo";
	}
	
	@RequestMapping(value="/add-todo",method= RequestMethod.POST)
	private String addTodoPost(ModelMap model, @Valid Todo todo, BindingResult result) {
		
		logger.debug("Description in add: "+todo.getDescription());
		logger.debug("locadate in add: "+todo.getTargetdate());
		if(result.hasErrors()) {
			logger.debug("Error: "+result.getNestedPath());
			return "addToDo";
			
		}
		String name= (String) model.get("name");
		todoservice.addNewTodo(name,todo.getDescription(),todo.getTargetdate(),false);		
		return "redirect:toDoList";
	}
	

	
	@RequestMapping(value="/delete-todo")
	private String deleteTodoPost(@RequestParam int id) {
		
		todoservice.deleteToDo(id);
		
		return "redirect:toDoList";
	}
	

	
	@RequestMapping(value="/update-todo",method= RequestMethod.GET)
	private String updateTodoPost(@RequestParam int id, ModelMap model) {
		Todo todo=todoservice.findById(id);
		model.addAttribute("todo", todo);		
		return "addToDo";
	}
	
	@RequestMapping(value="/update-todo",method= RequestMethod.POST)
	private String updateTodoPost(ModelMap model, @Valid Todo todo, BindingResult result) {
		
		logger.debug("Description in Update: "+todo.getDescription());
		logger.debug("locadate in Update: "+todo.getTargetdate());
		if(result.hasErrors()) {
			return "addToDo";
		}
		String name= (String) model.get("name");
		todo.setUsername(name);
		todoservice.updateToDo(todo);		
		return "redirect:toDoList";
	}
}
