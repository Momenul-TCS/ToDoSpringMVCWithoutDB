package com.momenulProject.springboot02.MyfirstwebappToDo.login01;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller
@SessionAttributes("name")
public class LoginController01 {
	
	@Autowired
	private AuthenticationService authenticationservice;
	
	
	@RequestMapping(value="/login",method = RequestMethod.GET)	
	public String login01() {
		
		return "login01";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String welcome(@RequestParam String name, @RequestParam String password,ModelMap model) {
		
		
		if(authenticationservice.authenticate(name, password)) {
			model.put("name", name);
			model.put("password", password);
			return "welcome";
		}
		model.put("errorMessage", "Invalid Login Credential! Please try Again");
		return "login01";
		
	}

}
